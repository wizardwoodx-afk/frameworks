# agent-frameworks-merged-1.1.0

The **merged agent framework**, complete: RISTER 1.1.0 — the single
native framework synthesised from six upstream projects — together with
the pinned record of what it merged, the per-framework design notes, the
debranding audit, the verification log, CI and build tooling.

## Layout

```
agent-frameworks-merged-1.1.0/
├── ARCHIVE.md                 this file
├── MANIFEST.txt               every file, its size and its SHA-256
├── README.md                  the repository overview
├── MANIFEST.json              the six upstream pins (repo, tag, commit)
├── .gitmodules                where each upstream is mounted
├── THIRD-PARTY-NOTICES.md     attribution for the six
├── Makefile                   bootstrap · verify · package · docs-check
├── .github/workflows/         CI: verification on every push
├── docs/                      architecture + 00–08 design notes
│   ├── architecture.html      generated from the source tree
│   ├── 01–06                  what each upstream contributed
│   ├── 07-rister.md           how the seven layers became one
│   ├── 08-debranding.md       the brand-neutrality audit
│   └── verification.md        measured results
├── rister/                    the merged framework (package + tests + examples)
├── scripts/                   bootstrap, verify, pins, docs, package
├── smoke/                     install-and-call smoke tests for the pins
└── vendor/                    the six upstream mount points (see below)
```

## The six upstreams are pinned, not copied

`vendor/*` are git submodules: the sources stay in their own repositories,
which keeps this project honest about what it did not write, and keeps a
release archive small. The pins are exact commits, recorded in
`MANIFEST.json` and `.gitmodules`.

| Upstream | Language | Role |
|---|---|---|
| `langgraph` | python | graph orchestration |
| `mastra` | typescript | agent/workflow runtime |
| `beeai-framework` | python | agent platform |
| `voltagent` | typescript | agent framework |
| `agent-governance-toolkit` | python | agent governance |
| `codex-security` | typescript | security scanning |

To materialise all six from a checkout of this project:

```bash
make bootstrap-fast     # depth-1 clones (~526 MB)
make bootstrap          # full history (~2.3 GB)
make status             # pinned vs checked-out commits
make verify             # install the pins and run their smoke tests
```

## Prove it

```bash
cd rister
PYTHONPATH=. python3 -m rister.tests    # 173 tests, no runner needed
PYTHONPATH=. python3 -m rister demo     # offline end-to-end walkthrough
PYTHONPATH=. python3 -m rister scan rister --fail-on-severity high
cd .. && python3 scripts/docs_check.py  # metadata and docs consistency
```

## Integrity

97 files, 773,602 bytes uncompressed. `MANIFEST.txt` lists a
SHA-256 for each one; compare a file with:

```bash
sha256sum -c <(awk 'NR>9 && NF==3 {print $1"  "substr($0, index($0,$3))}' MANIFEST.txt)
```

Built by `scripts/package.py`: sorted entries, fixed timestamps and uniform
permissions, so two builds of the same source are byte-identical.
